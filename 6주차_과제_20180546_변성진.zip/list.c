#include "list.h"

void list_push_back(struct list* list,struct list_elem* elem){

}

struct list_elem* list_pop_front(struct list* list){

}
