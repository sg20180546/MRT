#ifndef RECOMMEND_H_
#define RECOMMEND_H_
#define REC_CAL 8

#endif
